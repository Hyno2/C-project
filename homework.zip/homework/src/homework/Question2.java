package homework;
import java.util.*;

public class Question2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("몇 초?");
		int s = sc.nextInt();
		
		clock(s);
	}	

public static void clock(int s) {
	if(s>=3600) {
		System.out.println("오류 : 3600이상 입력하셨습니다.");
	}
	else {
		int h = s/60;
		int m = s%60;
		
		System.out.println(h+"분"+m+"초");
		}
	}
}