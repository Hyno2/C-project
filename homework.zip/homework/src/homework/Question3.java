package homework;

import java.util.Scanner;

public class Question3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("숫자 입력");
		int n = sc.nextInt();
		
		solution(n);
	}
	
	public static void solution(int n) {
	    int answer = 0;
	    
	    int[] num = new int[n + 1];
	    
	    // 2부터 n까지의 수를 배열에 넣는다
	    for(int i = 2; i <= n; i++) {
	        num[i] = i;  // 예) n=7, 출력-> 2, 3, 4, 5, 6, 7
	    }
	     
	    // 2부터 시작해서 그의 배수들을 0으로 만든다
	    // 후에 0이면 넘어가고 아니면 배수들을 0으로 만든다
	    for(int i = 2; i <= n; i++) {
	        if(num[i] == 0) continue;
	 
	        for(int j = 2*i; j <= n; j += i) {
	            num[j] = 0;
	        }
	    }     
	     
	    // 배열에서 0이 아닌 것들의 개수를 세어준다
	    for (int i = 0; i < num.length; i++) {
	        if(num[i] != 0) {
	            System.out.print(num[i]+" ");
	        }
	    }
	      
	}

}
