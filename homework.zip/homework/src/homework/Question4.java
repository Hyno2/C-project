package homework;

import java.util.Scanner;

public class Question4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("단어 갯수 입력");
		int n = sc.nextInt();
		
		String[] arr = new String[n];
		System.out.println("단어 입력");
		for(int i=0; i<n; i++) {
			arr[i] = sc.next();
		}
		System.out.println("찾을 단어 입력");
		String word = sc.next();
		
		boolean check = search(word, arr);
		if(check) {
			System.out.println("검색이 성공하였습니다.");
		}
		else {
			System.out.println("검색이 실패하였습니다.");
		}
	}
	public static boolean search(String a, String[] arr) {
		for(String word:arr) {
			if(word.equals(a)) {
				return true;
			}
		}
		return false;
	}
}
