package homework;
import java.util.Scanner;

public class Question1 {
	public static void main(String[] args) {
		int[] arr = new int[9];
		
		Scanner sc = new Scanner(System.in);
		System.out.println("몇 단 출력?");
		int n = sc.nextInt();
		
		for(int i=1; i<=10; i++) {
			arr[i-1] = n * i;
			System.out.println(arr[i-1]);
		}
	}
}
