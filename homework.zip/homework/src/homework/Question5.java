package homework;

import java.util.Scanner;

class coffee{
	int espresso;

	public int getEspresso() {
		return espresso;
	}

	public void setEspresso(int espresso) {
		this.espresso = espresso;
	}
	
	public coffee(int e){
		this.espresso = e;
	}
}

class americano extends coffee{
	int water;
	
	public americano(int e, int w) {
		super(e);
		this.water = w;
	}
	
	public void printAme() {
		System.out.println(this.espresso+"ml");
		System.out.println(this.water+"ml");
	}
	
	public void goodAme() {
		if(2*this.espresso==this.water) {
			System.out.println("황 금 비 율");
		}
		else if(this.espresso>this.water) {
			System.out.println("찐 한 아 메 리 카 노");
		}
		else {
			System.out.println("연 한 아 메 리 카 노");
		}
	}
}

class moka extends coffee{
	int milk;
	int choco;
	
	public moka(int e, int m, int c) {
		super(e);
		this.milk = m;
		this.choco = c;
	}
	
	public void printMoka() {
		System.out.println(this.espresso + "ml");
		System.out.println(this.milk + "ml");
		System.out.println(this.choco + "ml");
	}
	
	public void GoodMoka() {
		if(2*this.espresso==this.milk&&2*this.choco==this.milk) {
			System.out.println("황 금 비 율");
		}
		else {
			System.out.println("황 금 비 율 아 님");
		}
	}
}

public class Question5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("에스프레소양, 물 양 입력");
		americano ame = new americano(sc.nextInt(), sc.nextInt());
		
		ame.printAme();
		ame.goodAme();
		
		System.out.println("에스프레소양, 우유, 초코 양 입력");
		moka moka = new moka(sc.nextInt(), sc.nextInt(), sc.nextInt());
		
		moka.printMoka();
		moka.GoodMoka();
	}
}
